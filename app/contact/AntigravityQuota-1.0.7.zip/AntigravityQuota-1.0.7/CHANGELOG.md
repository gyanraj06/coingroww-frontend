# CHANGELOG

## 1.0.7 (2025-12-17)

- Added naming scheme for Gemini 3 Flash
